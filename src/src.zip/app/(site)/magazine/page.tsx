'use client'
import type { Metadata } from "next";
import { Tinos } from "next/font/google";
import FlipBookLoader from "@/components/magazine/FlipBookLoader";

const serif = Tinos({
    subsets: ["latin"],
    weight: ["400", "700"],
    style: ["normal", "italic"],
    variable: "--font-head",
});

// export const metadata: Metadata = {
//     title: "Freight Digital | Newspaper",
//     description: "Shipping, freight forwarding, logistics and trade news from the UAE.",
// };

export default function MagazinePage() {
    return (
        <main
            className={`${serif.variable} min-h-screen overflow-x-hidden bg-[#d8d1c4] px-1 py-2 sm:px-2 sm:py-3`}
        >
            <FlipBookLoader />
        </main>
    );
}

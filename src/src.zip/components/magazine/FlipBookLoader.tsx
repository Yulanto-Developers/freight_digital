'use client'

import { forwardRef, useEffect, useRef, useState } from "react";
import HTMLFlipBook from "react-pageflip";
import img1 from '@/../public/images/newspaper/img- (1).jpg'
import img2 from '@/../public/images/newspaper/img- (2).jpg'
import img3 from '@/../public/images/newspaper/img- (3).jpg'
import img4 from '@/../public/images/newspaper/img- (4).jpg'
import img5 from '@/../public/images/newspaper/img- (5).jpg'
import img6 from '@/../public/images/newspaper/img- (6).jpg'
import img7 from '@/../public/images/newspaper/img- (7).jpg'
import img8 from '@/../public/images/newspaper/img- (8).jpg'

// Each page MUST be a forwardRef component for react-pageflip
const Page = forwardRef<HTMLDivElement, { src: string; number: number }>(
    ({ src, number }, ref) => (
        <div ref={ref} className="bg-white">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
                src={src}
                alt={`Newspaper page ${number}`}
                draggable={false}
                style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
            />
        </div>
    )
);
Page.displayName = "Page";

export default function FlipbookLoader() {
    const images = [img1, img2, img3, img4, img5, img6, img7, img8];

    // Avoid SSR/hydration mismatch (react-pageflip relies on window)
    const [mounted, setMounted] = useState(false);
    useEffect(() => setMounted(true), []);

    if (!mounted) return null;

    return (
        <div className="flex w-full items-center justify-center overflow-hidden py-6">
            <HTMLFlipBook
                width={450}            // base page width
                height={600}           // base page height (3:4 ratio)
                size="stretch"         // scales with the container
                minWidth={300}         // container < 2 * minWidth (600px) => single page (mobile)
                maxWidth={600}
                minHeight={400}
                maxHeight={800}
                showCover={true}       // 1st (and last) page shown alone, centered
                usePortrait={true}     // enables single-page mode on small screens
                mobileScrollSupport={true}
                drawShadow={true}
                maxShadowOpacity={0.5}
                flippingTime={900}
                startPage={0}
                startZIndex={0}
                autoSize={true}
                clickEventForward={true}
                useMouseEvents={true}
                swipeDistance={30}
                showPageCorners={true}
                disableFlipByClick={false}
                className=""
                style={{}}
            >
                {images.map((img, i) => (
                    <Page key={i} src={img.src} number={i + 1} />
                ))}
            </HTMLFlipBook>
        </div>
    );
}
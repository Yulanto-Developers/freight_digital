import Image from 'next/image';
import Link from 'next/link';

interface BannerProps {
    page: string;
    url: string;
    
}

export default function Banner({ page,url }: BannerProps) {
    return (
        <section className="relative w-full h-[60vh] mt-28 overflow-hidden flex items-center justify-start">

            <Image
                src={url}
                alt="Banner Display"
                fill
                priority
                className="top-60"
            />


            <div className="absolute inset-0  z-10" />


            <div className="container mx-auto relative z-20 px-6 md:px-12">
                <div className="max-w-max bg-white/15 backdrop-blur-md border border-white/30 p-8 md:p-10 rounded-2xl shadow-2xl">


                    <h1 className="text-4xl md:text-4xl font-black uppercase tracking-wider text-[#f1671a] mb-4 drop-shadow-sm">
                        {page}
                    </h1>


                    <div className="flex items-center gap-2 text-xs md:text-sm font-bold uppercase tracking-[0.2em]">
                        <Link href="/" className="text-[#58595b] hover:text-white transition-colors">
                            Home
                        </Link>
                        <span className="text-slate-500">&gt;</span>
                        <span className="text-[#f1671a] hover:text-[#6e8296]">{page}</span>

                    </div>
                </div>
            </div>
        </section>
    );
}
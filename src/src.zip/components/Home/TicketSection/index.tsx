import React from "react";
import Link from "next/link";


const NewspaperIconSVG = () => (
    <svg
        viewBox="0 0 100 80"
        fill="currentColor"
        className="w-full h-auto text-[#0d1a2c] opacity-90"
        xmlns="http://www.w3.org/2000/svg"
    >

        <rect x="15" y="10" width="70" height="60" rx="3" fill="currentColor" stroke="#E5B592" strokeWidth="2" />


        <text x="50" y="30" textAnchor="middle" font-family="Verdana, sans-serif" font-weight="black" font-size="14" fill="#E5B592">
            NEWS
        </text>


        <rect x="25" y="38" width="50" height="4" fill="#E5B592" />
        <rect x="25" y="46" width="30" height="3" fill="#E5B592" />


        <rect x="25" y="56" width="45" height="2" fill="#E5B592" opacity="0.6" />
        <rect x="25" y="60" width="45" height="2" fill="#E5B592" opacity="0.6" />
        <rect x="25" y="64" width="40" height="2" fill="#E5B592" opacity="0.6" />


        <path d="M10,15 Q10,10 15,10 L85,10 Q90,10 90,15 L90,75 Q90,80 85,80 L15,80 Q10,80 10,75 Z" fill="currentColor" stroke="#E5B592" strokeWidth="1" opacity="0.4" transform="translate(5, 5)" />
    </svg>
);
// bg-[#ffffffa8]

const TicketSection = () => {
    return (
        <section className="dark:bg-[#58595b] -pt-3 font-sans">
            <div className="container px-4">

                <div className="relative md:mx-auto mx-0  overflow-hidden lg:-mb-48 bg-[#fff]  border-1 border-[#fff] rounded-xl 
                                [clip-path:polygon(30px_0%,calc(100%_-_30px)_0%,100%_30px,100%_calc(100%_-_30px),calc(100%_-_30px)_100%,30px_100%,0%_calc(100%_-_30px),0%_30px)]
                                before:content-[''] before:absolute before:inset-0 before:bg-[url('/images/paper-texture.png')] before:opacity-20 hover:translate-y-2">


                    <div className="absolute top-0 left-0 h-full w-8 flex flex-col justify-between p-1 z-10">
                        <div className="w-6 h-6 bg-[#58595b] rounded-full -ml-3"></div>
                        <div className="w-3 h-3 bg-[#58595b] rounded-full -ml-1.5 opacity-50"></div>
                        <div className="w-6 h-6 bg-[#58595b] rounded-full -ml-3"></div>
                        <div className="w-3 h-3 bg-[#58595b] rounded-full -ml-1.5 opacity-50"></div>
                        <div className="w-6 h-6 bg-[#58595b] rounded-full -ml-3"></div>
                        <div className="w-3 h-3 bg-[#f1651ae1] rounded-full -ml-1.5 opacity-50"></div>
                        <div className="w-6 h-6 bg-[#f1651ae1] rounded-full -ml-3"></div>
                    </div>


                    <div className="absolute top-0 -right-3 h-full w-8 flex flex-col justify-between p-1 z-10">
                        <div className="w-6 h-6 bg-[#58595b] rounded-full -mr-3"></div>
                        <div className="w-3 h-3 bg-[#58595b] rounded-full -mr-1.5 opacity-50"></div>
                        <div className="w-6 h-6 bg-[#58595b] rounded-full -mr-3"></div>
                        <div className="w-3 h-3 bg-[#58595b] rounded-full -mr-1.5 opacity-50"></div>
                        <div className="w-6 h-6 bg-[#58595b] rounded-full -mr-3"></div>
                        <div className="w-3 h-3 bg-[#f1651a79] rounded-full -mr-1.5 opacity-50"></div>
                        <div className="w-6 h-6 bg-[#f1651a00] rounded-full -mr-3"></div>
                    </div>



                    <div className="flex md:flex-row flex-col ">


                        <div className="md:w-3/4 w-full md:p-12 p-8 md:pr-4 relative border-r-2 border-dashed ">


                            <div className="absolute top-4 left-10 right-10 border-t border-black/10 dark:border-[#f1671a] h-1"></div>

                            <div className="flex flex-col items-center text-center">

                                <span className="uppercase font-serif font-bold tracking-widest text-[13px] mb-4 border-b-2 border-[#f1671a] pb-1 text-[#f1671a]">
                                    Special Edition • 2026
                                </span>


                                <h2 className="sm:text-5xl text-2xl leading-tight font-black uppercase italic tracking-tighter text-[#f1671a] max-w-2xl mb-8">
                                    Become a Part of the <br />
                                    <span className="bg-[#f1671a] text-[#fff]  px-2">Digital Evolution!</span>
                                </h2>


                                <Link
                                    href="/"
                                    className="group relative inline-block border-2 border-[#f1671a] bg-transparent p-1 transition-transform hover:scale-105"
                                >
                                    <span className="block border border-[#f1671a] py-3 px-10 uppercase font-bold text-[#f1671a] group-hover:bg-[#f1671a] group-hover:text-[#fff] transition-colors">
                                        subscription start @999
                                    </span>
                                </Link>


                                <p className="mt-8 text-[13px] uppercase font-medium tracking-widest opacity-80 text-[#f1671a]">
                                    - Limited Deal • Grab soon -
                                </p>
                            </div>


                            <div className="absolute bottom-4 left-10 right-10 border-b dark:border-[#f1671a] h-1"></div>


                            <div className="absolute left-8 bottom-8 w-24 md:w-32 opacity-80">
                                <NewspaperIconSVG />
                            </div>
                        </div>



                        <div className="md:w-1/4 w-full md:p-12 p-8 md:pl-4 bg-[#f1671a] text-[#fff]">
                            <div className="flex flex-col items-center h-full justify-between">


                                <div className="text-center w-full">
                                    <div className="border-b-2 border-[#fff] pb-1 mb-2">
                                        <p className="uppercase text-[12px] font-bold tracking-[0.2em]">Press Pass</p>
                                    </div>
                                    <p className="uppercase text-[13px] font-black tracking-widest">ID: #2026-SUB</p>
                                </div>


                                <div className="flex items-center gap-6 my-8 md:my-0">
                                    <div className="text-center border-r border-[#fff]/30 pt-2 pr-4">
                                        <p className="text-[11px] uppercase font-bold opacity-70 leading-none mb-1">Type</p>
                                        <p className="text-xl font-black leading-none">VIP</p>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-[11px] uppercase font-bold opacity-70 leading-none mb-1">Access</p>
                                        <p className="text-xl font-black leading-none">DAILY NEWS</p>
                                    </div>
                                </div>


                                <div className="mt-auto text-center w-full">
                                    <div className="flex flex-col justify-center">
                                        <p className="text-[14px]  font-black ">Buy for just</p>
                                        <p className="text-3xl font-black leading-none italic">@999.00</p>
                                    </div>

                                    <p className="text-[13px] uppercase font-bold tracking-widest mt-2 border-t border-[#fff] pt-1">
                                        Annual Subscription
                                    </p>
                                    <p className="text-[11px] uppercase mt-1 opacity-60">Non-Transferable</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default TicketSection;
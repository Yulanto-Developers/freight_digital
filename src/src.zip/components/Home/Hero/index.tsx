"use client";
import Link from "next/link";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, EffectFade, Pagination } from "swiper/modules";

// Swiper Styles
import "swiper/css";
import "swiper/css/effect-fade";
import "swiper/css/pagination";

const sliderData = [
    {
        tag: "",
        title: "Grow Your Logistics Business \n With Digital Power",
        desc: "Freight Digital helps freight forwarders, NVOCCs, customs brokers, shipping companies, transport operators, and logistics providers increase their online visibility, strengthen their brand, and generate qualified business opportunities through specialized digital marketing solutions.",
        bgImage: "/images/banner/banner-1.1.jpg",
        accent: "from-blue-600 to-cyan-400",
        text: '2.5rem'
    },
    {
        // Marketing Solutions Built for Freight Forwarders & Logistics Companies
        tag: "",
        title: "Marketing Solutions  Built for Freight Forwarders & Logistics Companies ",
        desc: "We specialize in digital marketing solutions for freight forwarders, NVOCCs, customs brokers, transport companies, and logistics providers—helping them increase brand visibility, generate qualified business leads, and grow their business globally.",
        bgImage: "/images/banner/banner-2.jpg",
        accent: "from-purple-600 to-pink-500",
        text: '2.5rem'
    },
];
export default function HeroSlider() {
    return (
        <section className="relative w-full h-full overflow-hidden paddding-hero-ls">
            <Swiper
                modules={[Autoplay, EffectFade, Pagination]}
                effect="fade"
                speed={1500}
                autoplay={{ delay: 3000 }}
                pagination={{ clickable: true }}
                className="w-full"
            >
                {sliderData.map((slide, i) => (
                    <SwiperSlide key={i} className="relative">
                        {/* Background Image with Gradient Overlay */}
                        <div
                            className="absolute  inset-0 bg-cover bg-center transition-transform duration-[5000ms] scale-110 swiper-slide-active:scale-100"
                            style={{ backgroundImage: `url(${slide.bgImage})` }}
                        >
                            {/* Dark Overlay - Critical for text readability */}
                            {/* <div className="absolute inset-0 bg-white/20 to-transparent"></div>
                            <div className="absolute inset-0 bg-black/60"></div> */}
                        </div>

                        {/* Content Container */}
                        <div className="container relative z-10 flex flex-col justify-center px-6">
                            <div className="max-w-3xl slide-content  md:py-25">
                                {/* chuma space purpose */}
                                <span className={`inline-block px-5 py-1.5 rounded-full text-xs font-black uppercase   mb-8 shadow-lg`}>
                                    {slide.tag ?? ''}
                                </span>

                                <h1 className={`text-6xl md:text-[${slide.text}] md:mt-36 font-black text-white leading-[1.05] mb-8 drop-shadow-2xl whitespace-pre-line`}>
                                    {slide.title}
                                </h1>

                                <p className="text-lg text-slate-200 text-justify  max-w-xl mb-12 leading-relaxed opacity-90">
                                    {slide.desc}
                                </p>

                                <div className="flex flex-wrap gap-6 mb-5">
                                    <Link href="/services" className="px-10 py-5 bg-white text-slate-900 font-bold rounded-2xl hover:bg-blue-50 transition-all duration-300 shadow-2xl hover:-translate-y-1">
                                        Our Solutions
                                    </Link>
                                    <Link href="/contact" className="px-10 py-5 bg-white/10 backdrop-blur-md border border-white/20 text-white font-bold rounded-2xl hover:bg-white/20 transition-all duration-300">
                                        Reach Us
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </SwiperSlide>
                ))}
            </Swiper>

            {/* Global Style overrides for Pagination */}
            <style jsx global>{`
        .swiper-pagination-bullet {
          background: #fff !important;
          opacity: 0.3;
          width: 12px;
          height: 12px;
          margin: 0 8px !important;
        }
        .swiper-pagination-bullet-active {
          opacity: 1;
          transform: scale(1.3);
        }
      `}</style>
        </section>
    );
}
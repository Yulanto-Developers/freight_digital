"use client";
import React from "react";
import Image from "next/image";
import { speakers } from "@/app/api/data";
import { usePathname } from "next/navigation";
import Link from "next/link";

const WorkSpeakers = ({ showTitle = true }) => {
  const pathname = usePathname();
  return (
    <>
      <section className={` dark:bg-[#58595b] ${pathname === "/" ? "" : ""}`}>
        {showTitle && (
          <div className="flex flex-col justify-center items-center">
            <span className="uppercase text-[11px] font-black italic px-2 py-1 bg-[#f1671a] rounded-xl tracking-wider text-[#fff] text-center">Industry Understanding</span>
            <h2 className="text-center text-[#fff] pb-12">Why Logistics Companies Choose Freight Digital</h2>

          </div>
        )}

        <div className="text-center md:pb-20 pb-8">

          <p data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000" className="text-[#ffffff] dark:text-opacity-90 text-lg font-normal max-w-920 m-auto">
            The logistics industry is highly competitive and relationship-driven. While referrals and agent networks remain important, a strong digital presence has become essential for attracting new customers and business partners. Freight Digital helps logistics companies improve online visibility, strengthen credibility, and generate qualified business inquiries through industry-focused digital marketing solutions.

          </p>
        </div>
        <div className="grid lg:grid-cols-5 sm:grid-cols-2 grid-cols-1 items-stretch gap-8 mx-7">
          {speakers.map((speaker, index) => (
            <div
              key={speaker.id}
              data-aos="fade-up"
              data-aos-delay={`${index * 300}`}
              data-aos-duration="1000"
              className={`col-span-1 group overflow-hidden ${index % 2 === 1 ? "lg:mt-28 mt-0" : ""
                }`}
            >
              <div className="overflow-hidden rounded-lg">
                <Image
                  src={speaker.src}
                  alt={speaker.alt}
                  width={0}
                  height={0}
                  quality={100}
                  layout="responsive"
                  sizes="100vh"
                  className=" object-cover w-full h-full transition-all duration-0.4s group-hover:scale-110"
                />
              </div>
              <div className="pt-6">
                <h6 className="text-[22px] leading-[2.25rem] font-bold text-secondary dark:text-white">
                  {speaker.name}
                </h6>
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default WorkSpeakers;
